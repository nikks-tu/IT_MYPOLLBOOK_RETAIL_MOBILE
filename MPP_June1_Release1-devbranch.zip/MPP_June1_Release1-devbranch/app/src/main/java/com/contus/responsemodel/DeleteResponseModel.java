package com.contus.responsemodel;

/**
 * Created by user on 1/27/2016.
 */
public class DeleteResponseModel {
    public String getSuccess() {
        return success;
    }

    private String success;

    public String getMsg() {
        return msg;
    }

    private String msg;
}
