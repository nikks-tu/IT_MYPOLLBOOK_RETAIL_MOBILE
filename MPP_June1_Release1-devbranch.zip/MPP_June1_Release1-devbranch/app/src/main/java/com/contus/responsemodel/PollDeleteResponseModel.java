package com.contus.responsemodel;

/**
 * Created by user on 12/30/2015.
 */
public class PollDeleteResponseModel {
    //success
    private String success;
    /**
     * getSuccess success
     * @return
     */
    public String getSuccess() {
        return success;
    }
    //success
    private String results;

    public String getMsg() {
        return msg;
    }

    //success
    private String msg;

    public String getResults() {
        return results;
    }
}
