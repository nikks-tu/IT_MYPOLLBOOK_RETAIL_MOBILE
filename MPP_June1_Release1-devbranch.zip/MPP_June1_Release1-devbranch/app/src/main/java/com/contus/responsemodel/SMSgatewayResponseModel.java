package com.contus.responsemodel;

/**
 * Created by user on 9/18/2015.
 */
public class SMSgatewayResponseModel {
    //Message
    private String message;
    //success
    private String success;
    /**
     * Get the success
     * @return success
     */

    public String getSuccess() {
        return success;
    }
    /**
     * Get the message
     * @return msg
     */
    public String getMsg() {
        return message;
    }



}
